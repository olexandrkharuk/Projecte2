paraula1 = input("Introdueix la primera paraula: ")
paraula2 = input("Introdueix la segona paraula: ")
paraula3 = input("Introdueix la tercera paraula: ")

print("La frase és:", paraula1, paraula2, paraula3)
